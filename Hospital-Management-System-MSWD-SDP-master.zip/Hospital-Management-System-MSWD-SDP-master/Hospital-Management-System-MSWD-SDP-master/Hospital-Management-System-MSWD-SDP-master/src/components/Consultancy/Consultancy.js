import React from 'react'
function Consultancy() {
    return ( 
        <div >
            Consultancy
        </div>
    )
}

export default Consultancy