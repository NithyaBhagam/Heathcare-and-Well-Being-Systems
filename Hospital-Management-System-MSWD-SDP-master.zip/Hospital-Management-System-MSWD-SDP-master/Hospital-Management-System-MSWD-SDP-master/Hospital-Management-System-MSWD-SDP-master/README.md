AIM - To make the Appointment Process Online in every Hospital
No alt text provided for this image

As we are the students of UG in K L University. We are having a subject which tells us about the design aspects of every project or business system. So with the help of that subject and also with the combination of many subjects, we had created a small regarding "Healthcare and well-being systems"

In this field, we made a lot of research and concluded to work on this particular topic which we feel is important in our business system.
Our Team Members
Madhav PVL - 2000030810
Sunkara Siva Avanthika -2000030971
Sri Nithya Bhagam -2000030953
No alt text provided for this image

Our Batch Number is 326
Health Care and Well-being System
Health care is one of the topmost prioritized business systems in this whole world. Growth in this field is too high if we work on it properly. Health care is nothing but taking care of the patient before the operation/surgery or after the operation/surgery.
It plays a major role in the hospital because along with the doctor the facilities of the hospital need to be perfectly all right so that it attracts more people to join this particular hospital.
User Research
The study of the target users
Our business system's main target group is the patients who come to that hospital.
Our main aim is to reduce the waiting time of the patient in any hospital.
We are thinking of an idea like even in the hospital itself they need to use our website to give the appointment so that from next time the people who stay at the reception will just say to the patient to book an appointment through this website and come to the hospital.
By Applying the Design Thinking Techniques we can easily complete our research and also find the errors in our case study.
Hospital Picture
No alt text provided for this image
Research and Findings
Questions to understand the user group
What are the basic requirements for an appointment regarding health?
How often do we need to visit a hospital for our overall health checkups?
What result can we expect from the local hospitals near to you?
What are the procedures for an emergency patient's appointment?
How many people daily come to visit you by checking about your hospital on google?
Reception Picture
No alt text provided for this image

Responses from them
What are the basic requirements for an appointment regarding health? The basic requirements are the patient's name, age, phone number, gender, address, blood group, Gmail, alternate phone number, and Previous health issues (Diabetic). These are some of the common/basic requirements for a patient which need not be filled every time for every new appointment they can be auto-filled if they click the patient's name.
How often do we need to visit a hospital for our overall health checkups? It depends upon the doctor's advice because some of the patients are required to visit the hospital more times but some patients will have very few visits to the hospital. Sometimes we even call the patient to come to the hospital if it's very serious so it's better if you just place some alarms/reminders for remembering the patient to come to the hospital for a checkup.
What result can we expect from the local hospitals near to you? Local hospitals won't have these many formalities because there may be only a single doctor in that hospital or sometimes he may not open the hospital some times a huge amount of patients may visit sometimes not even a single person visits the hospital. It's better if we just try something like a collab with the biggest hospitals to check the skill of the local doctor and send some of the patients to that doctor with some discount so that local doctors can also survive.
What are the procedures for an emergency patient's appointment? When a person visits a hospital for an emergency appointment, the duty doctors start a consultancy procedure in which a person is immediately examined and all required tests are performed. According to the results, the doctor shifts the patient into emergency word or ICU, or operation theatre.
How many people daily come to visit you by checking about your hospital on google? According to a survey 50% of people who choose to visit a hospital check the reviews of the hospital, note their contact information, check the address online.
Our Findings
No alt text provided for this image

User Persona
No alt text provided for this image

Videos and pics
https://youtu.be/p01k2S5V_zo

Interview Report
•The very first week we engaged ourselves in hospitals and got some information regarding the process of giving appointments.
• Users had low limited knowledge about mobile phones and their usage.
•We have learned how the appointment time is managed if the person who booked it did not show up.
•We had an experience where some users don’t know how to make online payments.
•We came across how does a health insurance claim work for a user. 
•We came across how the consultancy fee procedures differ from one hospital to another.
•By our survey we found that many users due to this corona pandemic want to book their appointments online in a particular time slot as they want to avoid waiting in the hospital.
Empathy Map
No alt text provided for this image
User Stories
As a user, I want to be healthy.
As a user when my family is sick I want to have the best treatment for them.
As a user, I want to reduce the waiting time in the hospital for an appointment.
As a user due to this pandemic, I prefer to have an online consultancy with a doctor rather than offline.
As a user I want the web application to be easy to use.
As a user, I need a single web application to satisfy all my medical needs instead of multiple applications which consists of few requirements.
As a user, I want to know which hospital provides what kind of specialists do they have.
The Final Users
Patient:- Here the patient will access the website/mobile application with his device and tries to book an appointment one day prior. Then the user needs to wait for some time to get a proper response from the hospital for the confirmation. Then he visits the hospital at the time of his appointment then after his visit is completed then he will give a review accordingly on both the Doctor's Treatment and Hospitality. With the help of that review, the administrator will assign the ratings and gives those customer reviews to that particular hospital.
Hospital (Staff):- Here the staff who are working in that hospital need to accept the appointment request sent from that particular patient if there is availability accordingly send a reply back after accepting the request else give a particular reason for the rejection
Administrator:- Here the administrator needs to collect all the responses from the patient who went to the hospital with the help of that response he needs to assign those ratings to that hospital and also make sure there will be customer feedback present there.
Conclusion
So this is all about our SDP-1 our main aim is to reduce the waiting time for appointments in every hospital. By making this procedure online through a mobile application. We are so happy if it reaches to correct set of people and works perfectly without any problem.
No alt text provided for this image
